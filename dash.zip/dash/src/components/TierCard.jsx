import React from "react";
import { CircularProgressbar, buildStyles } from "react-circular-progressbar";
import "react-circular-progressbar/dist/styles.css";
import "./styles/TierCard.css";

const TierCard = () => {
  const currentTier = "Platinum";
  const nextTier = "Diamond";
  const progressToNextTier = 75; // Example: 75% progress

  const tierColors = {
    Bronze: "#cd7f32",
    Silver: "#c0c0c0",
    Gold: "#ffd700",
    Platinum: "#e5e4e2",
    Diamond: "#b9f2ff",
  };

  return (
    <div className="tier-card">
      <h3 className="tier-title">Your Tier Progress</h3>
      <div className="tier-content">
        {/* Circular Progress Bar */}
        <div className="tier-progress">
          <CircularProgressbar
            value={progressToNextTier}
            text={`${progressToNextTier}%`}
            styles={buildStyles({
              textSize: "16px",
              textColor: "#fff",
              pathColor: tierColors[currentTier],
              trailColor: "#333",
            })}
          />
        </div>

        {/* Tier Information */}
        <div className="tier-info">
          <p className="tier-name" style={{ color: tierColors[currentTier] }}>
            {currentTier}
          </p>
          <p className="next-tier-text">Next: {nextTier}</p>
        </div>
      </div>

      {/* Tier Benefits (Structured Properly) */}
      <ul className="tier-benefits">
        <li>Exclusive rewards</li>
        <li>Priority support</li>
        <li>Discounts on vouchers</li>
      </ul>
    </div>
  );
};

export default TierCard;
