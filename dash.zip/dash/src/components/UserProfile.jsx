import React from 'react';
import './styles/UserProfile.css';

const UserProfile = () => {
  return (
    <div className="user-profile">
      <img src="avatar.png" alt="User Avatar" className="avatar" />
      <div className="user-details">
        <h2>John Doe</h2>
        <p className="rank">Platinum Member</p>
        <p className="email">john.doe@example.com</p>
      </div>
    </div>
  );
};

export default UserProfile;
