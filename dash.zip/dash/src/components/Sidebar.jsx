import React, { useState, useEffect } from "react";
import "./Styles/Sidebar.css";

const Sidebar = () => {
  const [isOpen, setIsOpen] = useState(window.innerWidth >= 1024);

  useEffect(() => {
    const handleResize = () => {
      setIsOpen(window.innerWidth >= 1024);
    };

    window.addEventListener("resize", handleResize);

    return () => {
      window.removeEventListener("resize", handleResize);
    };
  }, []);

  const toggleSidebar = () => {
    // if (window.innerWidth >= 1024) {
    //   return;
    // }
    setIsOpen((prev) => !prev);
  };

  return (
    <>
      {/* Profile Icon completely outside the sidebar */}
      <div className="profile-icon" onClick={toggleSidebar}>
        <img src="/logo.png" alt="Profile" />
      </div>

      {/* Sidebar */}
      <aside className={`sidebar ${isOpen ? "open" : "collapsed"}`}>
        <div className="profile-wrapper">
          <div className="profile-details">
            <div className="profile-name">Shraddha</div>
            <div className="profile-name">Chaudhari</div>
          </div>
        </div>

        <nav>
          <ul className="nav-links">
            <li className="nav-item">🏠 Dashboard</li>
            <li className="nav-item">👤 Change User Details</li>
            <li className="nav-item">🔒 Update Password</li>
            <li className="nav-item">🎁 My Rewards</li>
            <li className="nav-item">🎫 Redeemable Rewards</li>
            <li className="nav-item">💳 Vouchers</li>
          </ul>
        </nav>
      </aside>
    </>
  );
};

export default Sidebar;
