import React from 'react';
import './styles/TotalPoints.css';

const TotalPoints = () => {
  const totalPoints = 1250;
  const nextMilestone = 1500;
  const pointsNeeded = nextMilestone - totalPoints;
  const recentTripPoints = 15;
  const canRedeem = totalPoints >= 1000; // Example condition for redeemable rewards

  return (
    <div className="total-points-card">
      <h3>Total Points Earned</h3>
      <div className="points-content">
        <span role="img" aria-label="trophy" className="trophy-icon">🏆</span>
        <p className="points">{totalPoints} pts</p>
      </div>

      {canRedeem && <p className="redeem-message">🎁 You have enough points to redeem a reward!</p>}

      <p className="next-milestone">Next milestone: {nextMilestone} pts</p>
      <p className="points-left">{pointsNeeded} pts to go!</p>

      <p className="recent-points">🚆 Last trip earned: +{recentTripPoints} pts</p>
    </div>
  );
};

export default TotalPoints;
