import React from 'react';
import './styles/CO2Saved.css';

const CO2Saved = () => {
  const co2Saved = 500; // Example: 500 kg of CO2 saved
  const goal = 1000; // Example: Goal is 1000 kg
  const progress = (co2Saved / goal) * 100; // Calculate progress percentage

  // Dynamic encouragement message
  let encouragementMessage = "Keep going! You're helping the planet.";
  if (progress >= 75) {
    encouragementMessage = "🔥 You're in the top 10% of eco-friendly users!";
  } else if (progress >= 50) {
    encouragementMessage = "🌱 Halfway there! Keep reducing your carbon footprint!";
  } else if (progress >= 25) {
    encouragementMessage = "🚀 You're making great progress! Keep it up!";
  }

  return (
    <div className="co2-saved">
      <h3>CO2 Saved</h3>
      <div className="co2-content">
        <div className="co2-icon">
          <span role="img" aria-label="leaf">🌿</span>
        </div>
        <div className="co2-details">
          <p className="co2-amount">{co2Saved} kg</p>
          <p className="co2-goal">Goal: {goal} kg</p>
        </div>
      </div>

      <div className="progress-bar">
        <div className="progress" style={{ width: `${progress}%` }}></div>
      </div>

      <p className="co2-message">{encouragementMessage}</p>
    </div>
  );
};

export default CO2Saved;
