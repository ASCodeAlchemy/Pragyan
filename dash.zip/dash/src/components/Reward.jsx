import React from 'react';
import './styles/Rewards.css';

const Rewards = () => {
  return (
    <div className="rewards">
      <h3>My Rewards</h3>
      <button className="reward-button">Redeem Rewards</button>
    </div>
  );
};

export default Rewards;