import React from 'react';
import './styles/TripHistory.css';

const TripHistory = () => {
  // Sample trip history data
  const tripHistory = [
    {
      id: 1,
      startingPoint: 'Home',
      destination: 'Office',
      distance: '5 km',
      pointsEarned: 50,
      time: '08:30 AM',
    },
    {
      id: 2,
      startingPoint: 'Office',
      destination: 'Gym',
      distance: '3 km',
      pointsEarned: 30,
      time: '06:00 PM',
    },
    {
      id: 3,
      startingPoint: 'Gym',
      destination: 'Home',
      distance: '4 km',
      pointsEarned: 40,
      time: '07:30 PM',
    },
  ];

  return (
    <div className="trip-history">
      <h3>Trip History</h3>
      <table>
        <thead>
          <tr>
            <th>Starting Point</th>
            <th>Destination</th>
            <th>Distance</th>
            <th>Points Earned</th>
            <th>Time</th>
          </tr>
        </thead>
        <tbody>
          {tripHistory.map((trip) => (
            <tr key={trip.id}>
              <td>{trip.startingPoint}</td>
              <td>{trip.destination}</td>
              <td>{trip.distance}</td>
              <td>{trip.pointsEarned} pts</td>
              <td>{trip.time}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default TripHistory;