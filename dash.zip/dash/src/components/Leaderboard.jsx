import React from 'react';
import './styles/Leaderboard.css';

const Leaderboard = () => {
  // Sample leaderboard data
  const topUsers = [
    { name: 'User 1', points: 1000, tier: 'Platinum' },
    { name: 'User 2', points: 900, tier: 'Gold' },
    { name: 'User 3', points: 800, tier: 'Silver' },
    { name: 'User 4', points: 700, tier: 'Bronze' },
    { name: 'User 5', points: 600, tier: 'Bronze' },
  ];

  return (
    <div className="leaderboard">
      <h3>Leaderboard</h3>
      <ul>
        {topUsers.map((user, index) => (
          <li key={index}>
            <span className="user-rank">{index + 1}.</span>
            <span className="user-name">{user.name}</span>
            <span className="user-points">{user.points} pts</span>
            <span className="user-tier">{user.tier}</span>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default Leaderboard;