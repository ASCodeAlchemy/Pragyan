import React from 'react';
import './styles/TopNavbar.css';

const TopNavbar = () => {
  return (
    <div className="top-navbar">
      {/* GoPoint Logo on the Left */}
      <div className="logo">
        <img src="/logo.png" alt="GoPoint" className="gopoint-logo" />
      </div>
    </div>
  );
};

export default TopNavbar;
