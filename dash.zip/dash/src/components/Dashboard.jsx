import React from 'react';
import Sidebar from './Sidebar';
import TopNavbar from './TopNavbar';
import UserProfile from './UserProfile';
import CO2Saved from './CO2Saved';
import TotalPoints from './TotalPoints';
import TierCard from './TierCard';
import TripHistory from './TripHistory';
import Leaderboard from './Leaderboard';
import './styles/Dashboard.css';

const Dashboard = () => {
  return (
    <div className="dashboard-container">
      <div className="main-content" style={{margin: '1px'}}>
        <TopNavbar />
        <div className="dashboard-content">
          {/* Part 1: User Profile and CO2 Saved */}
          <div className="part-1">
            <UserProfile />
            <CO2Saved />
          </div>

          {/* Part 2: Leaderboard, Total Points, and Tier Card */}
          <div className="part-2">
            <Leaderboard />
            <TotalPoints />
            <TierCard />
          </div>

          {/* Part 3: Trip History */}
          <div className="part-3">
            <TripHistory />
          </div>
        </div>
      </div>
      <Sidebar />
    </div>
  );
};

export default Dashboard;